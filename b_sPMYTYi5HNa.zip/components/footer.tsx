import Link from "next/link"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

const navigation = {
  products: [
    { name: "Tirzepatide", href: "#" },
    { name: "Semaglutide", href: "#" },
    { name: "Retatrutide", href: "#" },
    { name: "BPC-157", href: "#" },
    { name: "All 47+ Products", href: "#products" },
  ],
  company: [
    { name: "About Us", href: "#about" },
    { name: "Science", href: "#science" },
    { name: "Quality", href: "#" },
    { name: "Careers", href: "#" },
  ],
  support: [
    { name: "FAQ", href: "#faq" },
    { name: "Shipping", href: "#" },
    { name: "Returns", href: "#" },
    { name: "Contact", href: "#contact" },
  ],
  legal: [
    { name: "Privacy Policy", href: "#" },
    { name: "Terms of Service", href: "#" },
    { name: "Research Disclaimer", href: "#" },
  ],
}

export function Footer() {
  return (
    <footer id="contact" className="bg-foreground text-background">
      <div className="mx-auto max-w-7xl px-6 py-16 lg:px-8 lg:py-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-8">
          {/* Left side - Brand and Newsletter */}
          <div className="max-w-md">
            <Link href="/" className="inline-block">
              <span className="font-serif text-3xl tracking-tight text-background">
                Peptide<span className="text-accent">XM</span>
              </span>
            </Link>
            <p className="mt-4 text-background/60 leading-relaxed">
              Premium research peptides with verified purity. Trusted by researchers 
              worldwide for quality and reliability.
            </p>
            
            <div className="mt-8">
              <p className="text-sm font-medium text-background mb-4">
                Subscribe to our newsletter
              </p>
              <form className="flex gap-2">
                <Input 
                  type="email" 
                  placeholder="Enter your email"
                  className="bg-background/10 border-background/20 text-background placeholder:text-background/40"
                />
                <Button variant="secondary">
                  Subscribe
                </Button>
              </form>
              <p className="mt-3 text-xs text-background/40">
                Get updates on new products and research. No spam, unsubscribe anytime.
              </p>
            </div>
          </div>

          {/* Right side - Links */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-sm font-medium text-background">Products</h3>
              <ul className="mt-4 space-y-3">
                {navigation.products.map((item) => (
                  <li key={item.name}>
                    <Link 
                      href={item.href}
                      className="text-sm text-background/60 hover:text-background transition-colors"
                    >
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-medium text-background">Company</h3>
              <ul className="mt-4 space-y-3">
                {navigation.company.map((item) => (
                  <li key={item.name}>
                    <Link 
                      href={item.href}
                      className="text-sm text-background/60 hover:text-background transition-colors"
                    >
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-medium text-background">Support</h3>
              <ul className="mt-4 space-y-3">
                {navigation.support.map((item) => (
                  <li key={item.name}>
                    <Link 
                      href={item.href}
                      className="text-sm text-background/60 hover:text-background transition-colors"
                    >
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-medium text-background">Legal</h3>
              <ul className="mt-4 space-y-3">
                {navigation.legal.map((item) => (
                  <li key={item.name}>
                    <Link 
                      href={item.href}
                      className="text-sm text-background/60 hover:text-background transition-colors"
                    >
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Bottom section */}
        <div className="mt-16 pt-8 border-t border-background/10">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <p className="text-sm text-background/40">
              &copy; {new Date().getFullYear()} PeptideXM. All rights reserved.
            </p>
            <p className="text-xs text-background/40 max-w-md">
              For research purposes only. Not for human consumption. 
              By purchasing, you agree to our terms of service.
            </p>
          </div>
        </div>
      </div>
    </footer>
  )
}
